"""
dispatch_router.py
─────────────────────
FastAPI routes for the Dispatch MCP.

Tool / Endpoint map:
  create_work_order         POST /api/dispatch/work_orders
  get_work_order            GET  /api/dispatch/work_orders/{work_order_id}
  list_work_orders          GET  /api/dispatch/work_orders
  update_work_order_status  POST /api/dispatch/work_orders/{work_order_id}/status
  get_dispatch_logs         GET  /api/dispatch/work_orders/{work_order_id}/logs
  list_experts              GET  /api/dispatch/experts
  get_dispatch_queue        GET  /api/dispatch/queue
  mark_no_dispatch_required POST /api/dispatch/no_dispatch
"""

import logging
from typing import Optional

from fastapi import APIRouter, HTTPException

from dispatch_mcp import handler
from dispatch_mcp.models import CreateWorkOrderRequest, UpdateWorkOrderStatusRequest, MarkNoDispatchRequest

log = logging.getLogger(__name__)

router = APIRouter()


@router.post(
    "/api/dispatch/work_orders",
    operation_id="create_work_order",
    summary="Create a new work order (Site Visit / Virtual Inspection / Drone Sweep) and dispatch log entry",
    tags=["Dispatch"],
)
def create_work_order(body: CreateWorkOrderRequest):
    """Inserts a new work_orders row (status 'Scheduled') and a 'Created' dispatch_logs row."""
    try:
        return handler.create_work_order(
            body.claim_id, body.claim_number, body.expert_id, body.expert_name, body.expert_type,
            body.scheduled_date, body.scheduled_time, body.customer_address, body.assigned_by,
            body.estimated_arrival, body.estimated_cost, body.priority, body.notes_to_expert,
            body.customer_phone, body.customer_email, body.dispatch_type,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        log.exception("create_work_order error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/api/dispatch/work_orders/{work_order_id}",
    operation_id="get_work_order",
    summary="Get a work order by work_order_id",
    tags=["Dispatch"],
)
def get_work_order(work_order_id: str):
    """Returns the work_orders row for the given work_order_id, or null."""
    return handler.get_work_order(work_order_id)


@router.get(
    "/api/dispatch/work_orders",
    operation_id="list_work_orders",
    summary="List work orders, optionally filtered by claim_id and/or status",
    tags=["Dispatch"],
)
def list_work_orders(claim_id: Optional[str] = None, status: Optional[str] = None):
    """Returns work_orders rows, optionally filtered."""
    return handler.list_work_orders(claim_id, status)


@router.post(
    "/api/dispatch/work_orders/{work_order_id}/status",
    operation_id="update_work_order_status",
    summary="Update a work order's status and log the transition",
    tags=["Dispatch"],
)
def update_work_order_status(work_order_id: str, body: UpdateWorkOrderStatusRequest):
    """
    Updates work_orders.status (setting started_at/completed_at/canceled_at
    as appropriate) and inserts a dispatch_logs row recording the previous
    and new status.
    """
    try:
        return handler.update_work_order_status(work_order_id, body.status, body.action_by, body.details)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        log.exception("update_work_order_status error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/api/dispatch/work_orders/{work_order_id}/logs",
    operation_id="get_dispatch_logs",
    summary="Get the dispatch audit trail for a work order",
    tags=["Dispatch"],
)
def get_dispatch_logs(work_order_id: str):
    """Returns dispatch_logs rows for the given work_order_id, ordered chronologically."""
    return handler.get_dispatch_logs(work_order_id)


@router.get(
    "/api/dispatch/experts",
    operation_id="list_experts",
    summary="List available experts to assign, optionally filtered by expert_type and/or city",
    tags=["Dispatch"],
)
def list_experts(expert_type: Optional[str] = None, city: Optional[str] = None, active_only: bool = True):
    """Returns experts rows ranked by rating desc, then completed_jobs desc."""
    return handler.list_experts(expert_type, city, active_only)


@router.get(
    "/api/dispatch/queue",
    operation_id="get_dispatch_queue",
    summary="List claims that may need an expert dispatched, with SLA/drone/specialty/latest-work-order signals",
    tags=["Dispatch"],
)
def get_dispatch_queue():
    """
    Returns one entry per claim with slaBreached, droneAvailable,
    recommendedSpecialty, ageDays, and (if one exists) the claim's latest
    work order status/dispatch_type plus a needsDispatch flag.
    """
    try:
        return handler.get_dispatch_queue()
    except Exception as e:
        log.exception("get_dispatch_queue error")
        raise HTTPException(status_code=500, detail=str(e))


@router.post(
    "/api/dispatch/no_dispatch",
    operation_id="mark_no_dispatch_required",
    summary="Record a 'No Visit Needed' decision for a claim",
    tags=["Dispatch"],
)
def mark_no_dispatch_required(body: MarkNoDispatchRequest):
    """
    Inserts a work_orders row with dispatch_type='No Visit Needed' and
    status='Not Required' (no expert/scheduling required), plus a matching
    dispatch_logs entry.
    """
    try:
        return handler.mark_no_dispatch_required(body.claim_id, body.claim_number, body.assigned_by, body.reason)
    except Exception as e:
        log.exception("mark_no_dispatch_required error")
        raise HTTPException(status_code=500, detail=str(e))
