"""
handler.py — Dispatch
────────────────────────
Creates and tracks work orders for vendor/expert dispatch, with a
dispatch_logs audit trail.
"""

import logging
import os
import random
import sys
from datetime import datetime
from typing import Optional

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "common"))

from db import get_db_connection, row_to_dict  # noqa: E402
from specialty_mapping import map_loss_type_to_specialty  # noqa: E402

log = logging.getLogger(__name__)

_VALID_DISPATCH_TYPES = {"Site Visit", "Virtual Inspection", "Drone Sweep", "No Visit Needed"}


def _rand_suffix(n: int) -> str:
    return "".join(random.choices("0123456789", k=n))


def create_work_order(claim_id: str, claim_number: str, expert_id: str, expert_name: str,
                       expert_type: str, scheduled_date: str, scheduled_time: str,
                       customer_address: str, assigned_by: str,
                       estimated_arrival: Optional[str] = None,
                       estimated_cost: Optional[float] = None,
                       priority: str = "Normal",
                       notes_to_expert: Optional[str] = None,
                       customer_phone: Optional[str] = None,
                       customer_email: Optional[str] = None,
                       dispatch_type: str = "Site Visit") -> dict:
    """
    Creates a work order for a physical Site Visit, a Virtual Inspection, or
    a Drone Sweep — the three dispatch_type values that require an assigned
    expert. For a claim that needs no visit at all, use
    mark_no_dispatch_required() instead, which does not require expert
    fields.
    """
    if dispatch_type not in _VALID_DISPATCH_TYPES:
        raise ValueError(f"dispatch_type must be one of {sorted(_VALID_DISPATCH_TYPES)}, got {dispatch_type!r}")
    if dispatch_type == "No Visit Needed":
        raise ValueError("Use mark_no_dispatch_required() for dispatch_type='No Visit Needed' — it does not require expert/scheduling fields.")

    work_order_id = f"WO-{_rand_suffix(6)}"
    conn = get_db_connection()
    try:
        cur = conn.cursor()
        cur.execute(
            """
            INSERT INTO work_orders (work_order_id, claim_id, claim_number, expert_id, expert_name,
                                      expert_type, scheduled_date, scheduled_time, estimated_arrival,
                                      estimated_cost, status, priority, notes_to_expert,
                                      customer_address, customer_phone, customer_email, assigned_by,
                                      dispatch_type)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s, 'Scheduled', %s, %s, %s, %s, %s, %s, %s)
            """,
            (work_order_id, claim_id, claim_number, expert_id, expert_name, expert_type,
             scheduled_date, scheduled_time, estimated_arrival, estimated_cost, priority,
             notes_to_expert, customer_address, customer_phone, customer_email, assigned_by,
             dispatch_type),
        )

        log_id = f"LOG-{_rand_suffix(6)}"
        cur.execute(
            """
            INSERT INTO dispatch_logs (log_id, work_order_id, claim_id, action, action_by, details,
                                        previous_status, new_status)
            VALUES (%s,%s,%s, 'Created', %s, %s, NULL, 'Scheduled')
            """,
            (log_id, work_order_id, claim_id, assigned_by,
             f"{dispatch_type} work order created for {expert_name} ({expert_type}) on {scheduled_date} {scheduled_time}"),
        )
        conn.commit()

        cur.execute("SELECT * FROM work_orders WHERE work_order_id = %s", (work_order_id,))
        return row_to_dict(cur.fetchone())
    finally:
        conn.close()


def mark_no_dispatch_required(claim_id: str, claim_number: str, assigned_by: str,
                               reason: Optional[str] = None) -> dict:
    """
    Records a "No Visit Needed" decision for a claim — the fourth Expert
    Dispatch UI action. Unlike create_work_order, this does not need an
    expert, a schedule, or a customer address: it inserts a work_orders row
    with dispatch_type='No Visit Needed' and status='Not Required' directly
    (skipping the normal 'Scheduled' -> 'In Progress' -> 'Completed' flow),
    plus a matching dispatch_logs entry, so the decision is auditable and
    shows up in the same queries as real dispatches (e.g. so the dispatch
    queue can exclude this claim from "needs dispatch" going forward).
    """
    work_order_id = f"WO-{_rand_suffix(6)}"
    conn = get_db_connection()
    try:
        cur = conn.cursor()
        cur.execute(
            """
            INSERT INTO work_orders (work_order_id, claim_id, claim_number, status, priority,
                                      notes_to_expert, assigned_by, dispatch_type)
            VALUES (%s,%s,%s, 'Not Required', 'Normal', %s, %s, 'No Visit Needed')
            """,
            (work_order_id, claim_id, claim_number, reason, assigned_by),
        )

        log_id = f"LOG-{_rand_suffix(6)}"
        cur.execute(
            """
            INSERT INTO dispatch_logs (log_id, work_order_id, claim_id, action, action_by, details,
                                        previous_status, new_status)
            VALUES (%s,%s,%s, 'No Visit Required', %s, %s, NULL, 'Not Required')
            """,
            (log_id, work_order_id, claim_id, assigned_by, reason or "No visit required."),
        )
        conn.commit()

        cur.execute("SELECT * FROM work_orders WHERE work_order_id = %s", (work_order_id,))
        return row_to_dict(cur.fetchone())
    finally:
        conn.close()


def get_work_order(work_order_id: str) -> Optional[dict]:
    conn = get_db_connection()
    try:
        cur = conn.cursor()
        cur.execute("SELECT * FROM work_orders WHERE work_order_id = %s", (work_order_id,))
        return row_to_dict(cur.fetchone())
    finally:
        conn.close()


def list_work_orders(claim_id: Optional[str] = None, status: Optional[str] = None) -> list:
    conn = get_db_connection()
    try:
        cur = conn.cursor()
        query = "SELECT * FROM work_orders WHERE 1=1"
        params = []
        if claim_id:
            query += " AND claim_id = %s"
            params.append(claim_id)
        if status:
            query += " AND status = %s"
            params.append(status)
        query += " ORDER BY id DESC"
        cur.execute(query, params)
        return row_to_dict(cur.fetchall())
    finally:
        conn.close()


def update_work_order_status(work_order_id: str, status: str, action_by: str,
                              details: Optional[str] = None) -> dict:
    conn = get_db_connection()
    try:
        cur = conn.cursor()
        cur.execute("SELECT * FROM work_orders WHERE work_order_id = %s", (work_order_id,))
        wo = row_to_dict(cur.fetchone())
        if not wo:
            raise ValueError(f"Work order {work_order_id} not found")

        previous_status = wo["status"]
        now = datetime.now().isoformat()

        updates = ["status = %s"]
        params = [status]
        if status == "In Progress":
            updates.append("started_at = %s")
            params.append(now)
        elif status == "Completed":
            updates.append("completed_at = %s")
            params.append(now)
        elif status == "Canceled":
            updates.append("canceled_at = %s")
            params.append(now)
            if details:
                updates.append("cancel_reason = %s")
                params.append(details)

        params.append(work_order_id)
        cur.execute(f"UPDATE work_orders SET {', '.join(updates)} WHERE work_order_id = %s", params)

        log_id = f"LOG-{_rand_suffix(6)}"
        cur.execute(
            """
            INSERT INTO dispatch_logs (log_id, work_order_id, claim_id, action, action_by, details,
                                        previous_status, new_status)
            VALUES (%s,%s,%s, 'Status Update', %s,%s,%s,%s)
            """,
            (log_id, work_order_id, wo["claim_id"], action_by, details, previous_status, status),
        )
        conn.commit()

        cur.execute("SELECT * FROM work_orders WHERE work_order_id = %s", (work_order_id,))
        return row_to_dict(cur.fetchone())
    finally:
        conn.close()


def get_dispatch_logs(work_order_id: str) -> list:
    conn = get_db_connection()
    try:
        cur = conn.cursor()
        cur.execute("SELECT * FROM dispatch_logs WHERE work_order_id = %s ORDER BY id ASC", (work_order_id,))
        return row_to_dict(cur.fetchall())
    finally:
        conn.close()


def list_experts(expert_type: Optional[str] = None, city: Optional[str] = None,
                  active_only: bool = True) -> list:
    """
    Looks up available experts to assign, optionally filtered by
    expert_type (e.g. "Property Inspector", "Drone Operator") and/or city.
    Ranked by rating desc, then completed_jobs desc — the same ranking
    convention VendorMatchingAgent uses for vendors.
    """
    conn = get_db_connection()
    try:
        cur = conn.cursor()
        query = "SELECT * FROM experts WHERE 1=1"
        params = []
        if active_only:
            query += " AND active IS TRUE"
        if expert_type:
            query += " AND expert_type = %s"
            params.append(expert_type)
        if city:
            query += " AND city = %s"
            params.append(city)
        query += " ORDER BY rating DESC NULLS LAST, completed_jobs DESC"
        cur.execute(query, params)
        return row_to_dict(cur.fetchall()) or []
    finally:
        conn.close()


def get_dispatch_queue() -> list:
    """
    Returns the list of claims that may need an expert dispatched, with the
    same signal fields the Expert Dispatch UI already computes client-side
    (slaBreached, droneAvailable, recommendedSpecialty, ageDays) — but
    computed once, here, so the UI and any agent asking "what needs
    dispatch?" get the same answer instead of two independently-maintained
    implementations. Also includes the most recent work order's status/
    dispatch_type for the claim, if one exists, so callers can distinguish
    "not yet dispatched" from "already dispatched, here's what happened".

    Cross-persona reads (claim_journey_master is owned by PolicyholderAgents,
    drone_evidence_summary by AdjusterAgents) are wrapped defensively: if
    either table is missing/unreachable, the corresponding signal degrades
    to a safe default (no SLA data / no drone availability) rather than
    failing the whole call.
    """
    conn = get_db_connection()
    try:
        cur = conn.cursor()

        cur.execute(
            """
            SELECT claim_number, policyholder_name, loss_type, severity, status,
                   location, filed_at
            FROM claims
            ORDER BY filed_at DESC
            """
        )
        claims = row_to_dict(cur.fetchall()) or []

        journey_by_claim = {}
        try:
            cur.execute(
                """
                SELECT claim_number, overall_sla_status, expected_completion_date,
                       current_stage_name
                FROM claim_journey_master
                """
            )
            for row in row_to_dict(cur.fetchall()) or []:
                journey_by_claim[str(row["claim_number"])] = row
        except Exception:
            log.warning("claim_journey_master unavailable — SLA/stage signals will default to unknown")
            conn.rollback()

        drone_claims = set()
        try:
            cur.execute("SELECT DISTINCT claim_id FROM drone_evidence_summary")
            drone_claims = {str(r["claim_id"]) for r in row_to_dict(cur.fetchall()) or []}
        except Exception:
            log.warning("drone_evidence_summary unavailable — droneAvailable will default to False")
            conn.rollback()

        latest_wo_by_claim = {}
        cur.execute(
            """
            SELECT DISTINCT ON (claim_number) claim_number, work_order_id, status, dispatch_type
            FROM work_orders
            ORDER BY claim_number, created_at DESC
            """
        )
        for row in row_to_dict(cur.fetchall()) or []:
            latest_wo_by_claim[str(row["claim_number"])] = row

    finally:
        conn.close()

    from datetime import datetime, timezone

    def _age_days(filed_at) -> int:
        if not filed_at:
            return 0
        try:
            filed = filed_at if hasattr(filed_at, "year") else datetime.fromisoformat(str(filed_at))
            if filed.tzinfo is None:
                filed = filed.replace(tzinfo=timezone.utc)
            return (datetime.now(timezone.utc) - filed).days
        except Exception:
            return 0

    queue = []
    for c in claims:
        key = str(c.get("claim_number"))
        journey = journey_by_claim.get(key)
        sla_status = (journey or {}).get("overall_sla_status") or ""
        age_days = _age_days(c.get("filed_at"))
        sla_breached = "breach" in sla_status.lower() or age_days > 7
        latest_wo = latest_wo_by_claim.get(key)
        queue.append({
            "claimNumber": key,
            "policyholder": c.get("policyholder_name") or "",
            "lossType": c.get("loss_type") or "",
            "severity": c.get("severity") or "",
            "status": c.get("status") or "",
            "location": (c.get("location") or "").replace("\n", ", "),
            "recommendedSpecialty": map_loss_type_to_specialty(c.get("loss_type"), default="Contractor"),
            "slaBreached": sla_breached,
            "ageDays": age_days,
            "droneAvailable": key in drone_claims,
            "stage": (journey or {}).get("current_stage_name") or "",
            "latestWorkOrderId": (latest_wo or {}).get("work_order_id"),
            "latestWorkOrderStatus": (latest_wo or {}).get("status"),
            "latestDispatchType": (latest_wo or {}).get("dispatch_type"),
            "needsDispatch": latest_wo is None,
        })
    return queue
