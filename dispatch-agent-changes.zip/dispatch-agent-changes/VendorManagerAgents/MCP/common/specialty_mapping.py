"""
specialty_mapping.py
─────────────────────
Single source of truth for loss_type -> vendor/expert specialty mapping.

Previously this heuristic existed in two places that could silently drift
apart: VendorMatchingAgent's handler.py (LOSS_TYPE_TO_SPECIALTY) and the
claims-solution-integration UI's vite-plugins/adjuster.ts
(specialtyForLossType). This module is the canonical version; both
vendor_matching_mcp.handler and dispatch_mcp.handler import it instead of
each keeping their own copy.
"""

from typing import Optional

LOSS_TYPE_TO_SPECIALTY = {
    "water damage": "Plumbing",
    "fire": "Roofing",
    "wind": "Roofing",
    "hail": "Roofing",
    "structural": "Contractor",
    "motor": "Auto Body",
    "auto": "Auto Body",
    "collision": "Auto Body",
    "electrical": "Electrical",
}

DEFAULT_SPECIALTY = "Contractor"


def map_loss_type_to_specialty(loss_type: Optional[str], default: Optional[str] = None) -> Optional[str]:
    """
    Maps a claim's loss_type to a recommended vendor/expert specialty.

    Substring match (not exact match) so values like "Motor / Auto Collision"
    or "Wind/Hail" still resolve correctly, matching the behavior the UI
    previously implemented locally in specialtyForLossType().
    """
    if not loss_type:
        return default
    lt = loss_type.strip().lower()
    for key, specialty in LOSS_TYPE_TO_SPECIALTY.items():
        if key in lt:
            return specialty
    return default
